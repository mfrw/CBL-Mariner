package yqlib

func selfOperator(_ *dataTreeNavigator, context Context, _ *ExpressionNode) (Context, error) {
	return context, nil
}
