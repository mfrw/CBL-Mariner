//go:build yq_notoml

package yqlib

func NewTomlDecoder() Decoder {
	return nil
}
