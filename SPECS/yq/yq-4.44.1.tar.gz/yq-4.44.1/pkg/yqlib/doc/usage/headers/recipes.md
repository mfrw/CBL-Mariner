# Recipes

These examples are intended to show how you can use multiple operators together so you get an idea of how you can perform complex data manipulation.

Please see the details [operator docs](https://mikefarah.gitbook.io/yq/operators) for details on each individual operator.
