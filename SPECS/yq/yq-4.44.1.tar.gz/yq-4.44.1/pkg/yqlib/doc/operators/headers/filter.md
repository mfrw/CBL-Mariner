# Filter

Filters an array (or map values) by the expression given. Equivalent to doing `map(select(exp))`.

