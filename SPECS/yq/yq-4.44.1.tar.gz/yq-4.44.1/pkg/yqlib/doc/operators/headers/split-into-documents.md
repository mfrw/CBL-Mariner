# Split into Documents

This operator splits all matches into separate documents
