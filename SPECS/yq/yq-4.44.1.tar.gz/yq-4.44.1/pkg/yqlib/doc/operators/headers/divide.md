# Divide

Divide behaves differently according to the type of the LHS:
* strings: split by the divider
* number: arithmetic division
