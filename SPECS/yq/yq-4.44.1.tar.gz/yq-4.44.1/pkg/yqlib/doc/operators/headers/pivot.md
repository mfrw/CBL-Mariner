# Pivot

Emulates the `PIVOT` function supported by several popular RDBMS systems.
