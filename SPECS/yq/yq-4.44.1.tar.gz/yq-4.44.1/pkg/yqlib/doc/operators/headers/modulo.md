# Modulo

Arithmetic modulo operator, returns the remainder from dividing two numbers.
