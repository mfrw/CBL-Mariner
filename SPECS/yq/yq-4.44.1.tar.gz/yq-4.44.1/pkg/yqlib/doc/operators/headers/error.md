# Error

Use this operation to short-circuit expressions. Useful for validation.
