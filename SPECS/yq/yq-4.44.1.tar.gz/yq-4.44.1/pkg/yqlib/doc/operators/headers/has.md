# Has

This operation returns true if the key exists in a map (or index in an array), false otherwise.
