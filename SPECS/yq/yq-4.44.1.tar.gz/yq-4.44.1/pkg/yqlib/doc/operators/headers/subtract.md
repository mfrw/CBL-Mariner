# Subtract

You can use subtract to subtract numbers as well as remove elements from an array.
