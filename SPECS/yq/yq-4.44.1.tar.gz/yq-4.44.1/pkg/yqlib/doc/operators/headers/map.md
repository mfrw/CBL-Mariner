# Map

Maps values of an array. Use `map_values` to map values of an object.
