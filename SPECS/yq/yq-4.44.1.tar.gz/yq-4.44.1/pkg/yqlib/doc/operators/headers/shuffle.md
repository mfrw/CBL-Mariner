# Shuffle

Shuffles an array. Note that this command does _not_ use a cryptographically secure random number generator to randomise the array order.

