# Alternative (Default value)

This operator is used to provide alternative (or default) values when a particular expression is either null or false.
