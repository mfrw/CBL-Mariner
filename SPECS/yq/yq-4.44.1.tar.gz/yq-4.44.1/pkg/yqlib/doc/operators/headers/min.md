# Min

Computes the minimum among an incoming sequence of scalar values.
