# Document Index

Use the `documentIndex` operator (or the `di` shorthand) to select nodes of a particular document.
