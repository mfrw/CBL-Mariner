# Omit

Works like `pick`, but instead you specify the keys/indices that you _don't_ want included.
