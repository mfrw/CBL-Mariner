# Max

Computes the maximum among an incoming sequence of scalar values.
