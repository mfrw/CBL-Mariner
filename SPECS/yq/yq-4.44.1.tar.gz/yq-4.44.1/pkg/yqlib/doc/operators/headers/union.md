# Union

This operator is used to combine different results together.
