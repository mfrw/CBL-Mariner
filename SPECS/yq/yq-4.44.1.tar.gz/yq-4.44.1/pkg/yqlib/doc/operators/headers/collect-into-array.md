# Collect into Array

This creates an array using the expression between the square brackets.

