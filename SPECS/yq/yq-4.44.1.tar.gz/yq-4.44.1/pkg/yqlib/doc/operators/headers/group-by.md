# Group By

This is used to group items in an array by an expression.
