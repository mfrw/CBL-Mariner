# Pipe

Pipe the results of an expression into another. Like the bash operator.
