# Unique

This is used to filter out duplicated items in an array. Note that the original order of the array is maintained.

