#!/bin/bash

npx cspell --no-progress "**/*.{sh,go}"